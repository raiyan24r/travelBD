import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:travel_app/SizeConfig.dart';
import '../ClassesData.dart';
import '../CustomDistrictButton.dart';

class PanelRajshahi extends StatefulWidget {
  PanelRajshahi({Key key}) : super(key: key);

  @override
  _PanelRajshahiState createState() => _PanelRajshahiState();
}

var rajshahicity = new Districts("rajshahi", false);
var nawabganjcity = new Districts("nawabganj", false);
var naogaoncity = new Districts("naogaon", false);
var jaipurhatcity = new Districts("jaipurhat", false);
var bogracity = new Districts("bogra", false);
var pabnacity = new Districts("pabna", false);
var sirajganjcity = new Districts("sirajganj", false);
var natorecity = new Districts("natore", false);

class _PanelRajshahiState extends State<PanelRajshahi> {
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.only(top: 30),
        child: Container(
          height: h(75) * .95,
          width: h(75) * .95 * .65,
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black45,
              ),
              BoxShadow(
                color: Colors.white,
                spreadRadius: -1.0,
                blurRadius: 1.0,
              ),
            ],
          ),
          child: Center(
              child: Stack(
            children: <Widget>[
              SvgPicture.asset(
                'assets/images/rajshahi.svg',
              ),
              DistrictButton('RAJSHAHI', rajshahicity, -.3, .1),
              DistrictButton('NAWABGANJ', nawabganjcity, -.9, -.1),
              DistrictButton('NAOGAON', naogaoncity, -.2, -.3),
              DistrictButton('JAIPURHAT', jaipurhatcity, .2, -.42),
              DistrictButton('BOGRA', bogracity, .58, -.2),
              DistrictButton('PABNA', pabnacity, .58, .4),
              DistrictButton('SIRAJGANJ', sirajganjcity, .79, .175),
              DistrictButton('NATORE', natorecity, .2, .175),
            ],
          )),
        ));
  }
}
