import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../ClassesData.dart';
import 'package:travel_app/SizeConfig.dart';
import '../CustomDistrictButton.dart';

class PanelRangpur extends StatefulWidget {
  PanelRangpur({Key key}) : super(key: key);

  @override
  _PanelRangpurState createState() => _PanelRangpurState();
}

var rangpurcity = new Districts("rangpur", false);
var dinajpurcity = new Districts("dinajpur", false);
var thakurgaoncity = new Districts("thakurgaon", false);
var panchagarhcity = new Districts("panchagarh", false);
var nilfamaricity = new Districts("nilfamari", false);
var lalmonirhatcity = new Districts("lalmonirhat", false);
var kurigramcity = new Districts("kurigram", false);
var gaibandhacity = new Districts("gaibandha", false);

class _PanelRangpurState extends State<PanelRangpur> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 30),
      child: Container(
          height: h(75) * .95,
          width: h(75) * .95 * .65,
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black45,
              ),
              BoxShadow(
                color: Colors.white,
                spreadRadius: -1.0,
                blurRadius: 1.0,
              ),
            ],
          ),
          child: Stack(
            children: <Widget>[
              SvgPicture.asset(
                'assets/images/rangpur.svg',
              ),
              DistrictButton('RANGPUR', rangpurcity, 0.3, 0.1),
              DistrictButton('DINAJPUR', dinajpurcity, -0.3, 0.05),
              DistrictButton('THAKURGAON', thakurgaoncity, -0.9, -0.2),
              DistrictButton('PANCHAGARH', panchagarhcity, -0.5, -0.5),
              DistrictButton('NILFAMARI', nilfamaricity, -0.05, -0.3),
              DistrictButton('LALMONIRHAT', lalmonirhatcity, 0.5, -0.185),
              DistrictButton('KURIGRAM', kurigramcity, 0.85, -0.05),
              DistrictButton('GAIBANDHA', gaibandhacity, 0.7, 0.3),
            ],
          )),
    );
  }
}
